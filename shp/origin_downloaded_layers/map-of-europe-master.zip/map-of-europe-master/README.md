# Map of Europe

Map includes all European Countries plus Israel.

####[Preview it here](https://github.com/leakyMirror/map-of-europe/blob/master/TopoJSON/europe.topojson)

## How to use it
Please read these two brilliant tutorials by [Mike Bostock](https://twitter.com/mbostock) about making maps in a browser using D3.js library:<br />
[Let’s Make a Map](http://bost.ocks.org/mike/map/)<br />
[Let’s Make a Bubble Map](http://bost.ocks.org/mike/bubble-map/)<br />
